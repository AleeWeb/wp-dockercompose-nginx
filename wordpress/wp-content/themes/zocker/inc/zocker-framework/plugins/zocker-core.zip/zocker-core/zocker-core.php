<?php
/**
 * Plugin Name: Zocker Core
 * Description: This is a helper plugin of zocker theme
 * Version:     1.0
 * Author:      Vecurosoft
 * Author URI:  http://vecurosoft.com/
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 * Text Domain: zocker
 */
 // Blocking direct access
if( ! defined( 'ABSPATH' ) ) {
    exit();
}

// Define Constant
define( 'ZOCKER_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'ZOCKER_PLUGIN_INC_PATH', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'ZOCKER_PLUGIN_CMB2EXT_PATH', plugin_dir_path( __FILE__ ) . 'cmb2-ext/' );
define( 'ZOCKER_PLUGIN_WIDGET_PATH', plugin_dir_path( __FILE__ ) . 'inc/widgets/' );
define( 'ZOCKER_PLUGDIRURI', plugin_dir_url( __FILE__ ) );
define( 'ZOCKER_ADDONS', plugin_dir_path( __FILE__ ) .'addons/' );
define( 'ZOCKER_CORE_PLUGIN_TEMP', plugin_dir_path( __FILE__ ) .'zocker-template/' );

// load textdomain
load_plugin_textdomain( 'zocker', false, basename( dirname( __FILE__ ) ) . '/languages' );

//include file.
require_once ZOCKER_PLUGIN_INC_PATH .'zockercore-functions.php';
require_once ZOCKER_PLUGIN_INC_PATH . 'MCAPI.class.php';
require_once ZOCKER_PLUGIN_INC_PATH .'zockerajax.php';
require_once ZOCKER_PLUGIN_INC_PATH .'builder/builder.php';

require_once ZOCKER_PLUGIN_CMB2EXT_PATH . 'cmb2ext-init.php';

//Widget
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'recent-post-widget.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'contact-info-widget.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'offcanvas-contact-info.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'social-widget.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'about-us-widget.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'footer-about-us.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'gallery-widget.php';
require_once ZOCKER_PLUGIN_WIDGET_PATH . 'blog-post-tab.php';

//addons
require_once ZOCKER_ADDONS . 'addons.php';