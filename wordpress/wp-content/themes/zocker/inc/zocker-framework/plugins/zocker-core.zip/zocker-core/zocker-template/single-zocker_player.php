<?php 

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    // header
    get_header();
	
	echo '<section class="vs-player-wrapper space-top newsletter-pb">';
	  	echo '<div class="container">';
	    	echo '<div class="row">';
                if ( is_active_sidebar( 'zocker-player-sidebar' ) ) {
                    $zocker_player_class = "col-lg-8";
                }else{
                    $zocker_player_class = "col-lg-12";
                }
    	    	echo '<div class="'.esc_attr( $zocker_player_class ).'">';
    				while( have_posts( ) ) :
    	                the_post();
    	                the_content();

    	            endwhile;
    	            wp_reset_postdata();
    			echo '</div>';
                if ( is_active_sidebar( 'zocker-player-sidebar' ) ) {
                    get_sidebar( 'player' );
                }
			echo '</div>';
		echo '</div>';
	echo '</section>';
	
	get_footer();