<?php 

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    // header
    get_header();
	
    echo '<section class="vs-member-area vs-member-layout2 space-top newsletter-pb">';
        echo '<div class="container">';
            echo '<div class="row justify-content-center">';
				if( have_posts() ):
					while( have_posts() ):
						the_post();
						echo '<div class="col-xl-3 col-lg-4 col-sm-6">';
                            echo '<div class="vs-member image-scale-hover">';
                                if( has_post_thumbnail( ) ){
                                    echo '<div class="member-img">';
                                        echo '<a href="'.esc_url( get_permalink() ).'">';
                                            the_post_thumbnail( 'full', array( 'class' => 'w-100' ) );
                                        echo '</a>';
                                    echo '</div>';
                                }
                                echo '<div class="member-content">';
                                    echo '<div class="links-wrap text-start position-relative mb-30">';
                                    $social_link = get_post_meta( get_the_ID(), '_zocker_player_social_group', true );
                                        if( ! empty( $social_link ) ){
                                            echo '<span class="icon-btn3 style-white plus-icon"><i class="far fa-plus text-white"></i></span>';
                                            echo '<div class="member-links">';
                                                foreach( $social_link as $single_icon ){
                                                    echo '<a href="'.esc_url( $single_icon['_zocker_player_social_profile_link'] ).'" class="icon-btn3"><i class="fab '.esc_attr( $single_icon['_zocker_player_social_profile_icon'] ).'"></i></a>';
                                                }
                                            echo '</div>';
                                        }
                                    echo '</div>';
                                    if( get_the_title() ){
                                        echo '<h3 class="member-name h5 mb-0 text-white"><a href="'.esc_url( get_permalink() ).'">'.esc_html( get_the_title() ).'</a></h3>';
                                    }
                                    if( ! empty( zocker_meta( 'zocker_player_designation' ) ) ){
                                        echo '<span class="degi text-white">'.esc_html( zocker_meta( 'zocker_player_designation' ) ).'</span>';
                                    }
                                echo '</div>';
                            echo '</div>';
						echo '</div>';
					endwhile;
					wp_reset_postdata();
				endif;
			echo '</div>';
		echo '</div>';
	echo '</section>';
	
	get_footer();