<?php
/**
 * @Packge     : Zocker
 * @Version    : 1.0
 * @Author     : Vecurosoft
 * @Author URI : https://www.vecurosoft.com/
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    /**
     * Admin Custom Login Logo
     */
    function zocker_custom_login_logo() {
        $logo = ! empty( zocker_opt( 'zocker_admin_login_logo', 'url' ) ) ? zocker_opt( 'zocker_admin_login_logo', 'url' ) : '' ;
        if( isset( $logo ) && !empty( $logo ) ){
            echo '<style type="text/css">body.login div#login h1 a { background-image:url('.esc_url( $logo ).'); }</style>';
        }
    }
    add_action( 'login_enqueue_scripts', 'zocker_custom_login_logo' );

    /**
    * Admin Custom css
    */

    add_action( 'admin_enqueue_scripts', 'zocker_admin_styles' );

    function zocker_admin_styles() {
        // $zocker_admin_custom_css = ! empty( zocker_opt( 'zocker_theme_admin_custom_css' ) ) ? zocker_opt( 'zocker_theme_admin_custom_css' ) : '';
        if ( ! empty( $zocker_admin_custom_css ) ) {
            $zocker_admin_custom_css = str_replace(array("\r\n", "\r", "\n", "\t", '    '), '', $zocker_admin_custom_css);
            echo '<style rel="stylesheet" id="zocker-admin-custom-css" >';
                echo esc_html( $zocker_admin_custom_css );
            echo '</style>';
        }
    }
    
    // share button code
    function zocker_social_sharing_buttons( ) {

        // Get page URL
        $URL = get_permalink();
        $Sitetitle = get_bloginfo('name');

        // Get page title
        $Title = str_replace( ' ', '%20', get_the_title());

        // Construct sharing URL without using any script

        $twitterURL = 'https://twitter.com/share?text='.esc_html( $Title ).'&url='.esc_url( $URL );
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.esc_url( $URL );
        $pinteresturl = 'http://pinterest.com/pin/create/link/?url='.esc_url( $URL ).'&media='.esc_url(get_the_post_thumbnail_url()).'&description='.wp_kses_post(get_the_title());
        $linkedin = 'https://www.linkedin.com/shareArticle?mini=true&url='.esc_url( $URL ).'&title='.esc_html( $Title );

        // Add sharing button at the end of page/page content
        $content = '';

        $content .= '<li class="nav-item"><a class="nav-link facebook" href="'.esc_url( $facebookURL ).'" target="_blank"><span class="fab fa-facebook-f"> '.esc_html__( 'Facebook', 'zocker' ).'</span></a></li>';
        $content .= '<li class="nav-item"><a class="nav-link twitter" href="'. esc_url( $twitterURL ) .'" target="_blank"><span class="fab fa-twitter">'.esc_html__( 'Twitter', 'zocker' ).'</span></a></li>';
        $content .= '<li class="nav-item"><a class="nav-link instagram" href="'.esc_url( $pinteresturl ).'" target="_blank"><span class="fab fa-pinterest">'.esc_html__( 'Pinterest', 'zocker' ).'</span></a></li>';
        $content .= '<li class="nav-item"><a class="nav-link linkedin" href="'.esc_url( $linkedin ).'" target="_blank"><span class="fab fa-linkedin">'.esc_html__( 'Linkedin', 'zocker' ).'</span></a></li>';
        return $content;
    };
    
    // Social share button code for player Details
    function zocker_social_sharing_buttons_for_player_details( ) {

        // Get page URL
        $URL = get_permalink();
        $Sitetitle = get_bloginfo('name');

        // Get page title
        $Title = str_replace( ' ', '%20', get_the_title());

        // Construct sharing URL without using any script

        $twitterURL = 'https://twitter.com/share?text='.esc_html( $Title ).'&url='.esc_url( $URL );
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.esc_url( $URL );
        $pinteresturl = 'http://pinterest.com/pin/create/link/?url='.esc_url( $URL ).'&media='.esc_url(get_the_post_thumbnail_url()).'&description='.wp_kses_post(get_the_title());
        $linkedin = 'https://www.linkedin.com/shareArticle?mini=true&url='.esc_url( $URL ).'&title='.esc_html( $Title );

        // Add sharing button at the end of page/page content
        $content = '';

        $content .= '<a class="icon-btn3 size-40" href="'.esc_url( $facebookURL ).'" target="_blank"><i class="fab fa-facebook-f"></i></a>';
        $content .= '<a class="icon-btn3 size-40" href="'. esc_url( $twitterURL ) .'" target="_blank"><i class="fab fa-twitter"></i></a>';
        $content .= '<a class="icon-btn3 size-40" href="'.esc_url( $pinteresturl ).'" target="_blank"><i class="fab fa-pinterest"></i></a>';
        $content .= '<a class="icon-btn3 size-40" href="'.esc_url( $linkedin ).'" target="_blank"><i class="fab fa-linkedin"></i></a>';
        return $content;
    };

    //add SVG to allowed file uploads
    function zocker_mime_types( $mimes ) {
        $mimes['svg'] = 'image/svg+xml';
        $mimes['svgz'] = 'image/svgz+xml';
        $mimes['exe'] = 'program/exe';
        $mimes['dwg'] = 'image/vnd.dwg';
        return $mimes;
    }
    add_filter('upload_mimes', 'zocker_mime_types');

    function zocker_wp_check_filetype_and_ext( $data, $file, $filename, $mimes ) {
        $wp_filetype = wp_check_filetype( $filename, $mimes );
        $ext         = $wp_filetype['ext'];
        $type        = $wp_filetype['type'];
        $proper_filename = $data['proper_filename'];

        return compact( 'ext', 'type', 'proper_filename' );
    }
    add_filter('wp_check_filetype_and_ext','zocker_wp_check_filetype_and_ext',10,4);

    if( ! function_exists('zocker_get_user_role_name') ){
        function zocker_get_user_role_name( $user_ID ){
            global $wp_roles;

            $user_data      = get_userdata( $user_ID );
            $user_role_slug = $user_data->roles[0];
            return translate_user_role( $wp_roles->roles[$user_role_slug]['name'] );
        }
    }

    add_image_size( 'blog-sidebar-size', 90, 90, true );
    add_image_size( 'home-slider-blog-image', 370, 240, true );
    add_image_size( 'home-slider-blog-image-two', 370, 356, true );
    add_image_size( 'home-slider-blog-image-three', 269, 372, true );
    add_image_size( 'home-slider-blog-image-four', 370, 490, true );
    add_image_size( 'home-slider-blog-image-five', 100, 100, true );
    add_image_size( 'home-slider-blog-image-six', 360, 226, true );
    add_image_size( 'home-slider-blog-image-seven', 116, 116, true );
    add_image_size( 'home-slider-blog-image-eight', 220, 220, true );
    add_image_size( 'player-details-image-size', 170, 150, true );

    // Player Post Type
    add_action( 'init','zocker_player', 0 );

    function zocker_player(){
        $labels = array(
            'name'               => esc_html__( 'Players', 'post Category general name', 'zocker' ),
            'singular_name'      => esc_html__( 'Player', 'post Category singular name', 'zocker' ),
            'menu_name'          => esc_html__( 'Players', 'admin menu', 'zocker' ),
            'name_admin_bar'     => esc_html__( 'Player', 'add new on admin bar', 'zocker' ),
            'add_new'            => esc_html__( 'Add New', 'Player', 'zocker' ),
            'add_new_item'       => esc_html__( 'Add New Player', 'zocker' ),
            'new_item'           => esc_html__( 'New Player', 'zocker' ),
            'edit_item'          => esc_html__( 'Edit Player', 'zocker' ),
            'view_item'          => esc_html__( 'View Player', 'zocker' ),
            'all_items'          => esc_html__( 'All Players', 'zocker' ),
            'search_items'       => esc_html__( 'Search Players', 'zocker' ),
            'parent_item_colon'  => esc_html__( 'Parent Players:', 'zocker' ),
            'not_found'          => esc_html__( 'No Players found.', 'zocker' ),
            'not_found_in_trash' => esc_html__( 'No Players found in Trash.', 'zocker' ),
        );

        $args = array(
            'labels'             => $labels,
            'description'        => esc_html__( 'Description.', 'zocker' ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-index-card',
            'supports'           => array( 'title','thumbnail','editor','excerpt','elementor' ),
            'rewrite'            => array( 'slug' => 'all-players' ),
        );

        register_post_type( 'zocker_player', $args );

        $labels = array(
            'name'                       => esc_html__( 'Categories', 'taxonomy general name', 'zocker' ),
            'singular_name'              => esc_html__( 'Category', 'taxonomy singular name', 'zocker' ),
            'search_items'               => esc_html__( 'Search Categorys', 'zocker' ),
            'popular_items'              => esc_html__( 'Popular Categorys', 'zocker' ),
            'all_items'                  => esc_html__( 'All Categorys', 'zocker' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Category', 'zocker' ),
            'update_item'                => esc_html__( 'Update Category', 'zocker' ),
            'add_new_item'               => esc_html__( 'Add New Category', 'zocker' ),
            'new_item_name'              => esc_html__( 'New Category Name', 'zocker' ),
            'separate_items_with_commas' => esc_html__( 'Separate Categorys with commas', 'zocker' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove Categorys', 'zocker' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used Categorys', 'zocker' ),
            'not_found'                  => esc_html__( 'No Categorys found.', 'zocker' ),
            'menu_name'                  => esc_html__( 'Categories', 'zocker' ),
        );

        $args = array(
            'hierarchical'          => true,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'show_in_rest'          => true,
            'rewrite'               => array( 'slug' => 'player-category' ),
        );

        register_taxonomy( 'player_category', 'zocker_player', $args );

        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                       => esc_html__( 'Tags', 'taxonomy general name', 'zocker' ),
            'singular_name'              => esc_html__( 'Tag', 'taxonomy singular name', 'zocker' ),
            'search_items'               => esc_html__( 'Search Tags', 'zocker' ),
            'popular_items'              => esc_html__( 'Popular Tags', 'zocker' ),
            'all_items'                  => esc_html__( 'All Tags', 'zocker' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Tag', 'zocker' ),
            'update_item'                => esc_html__( 'Update Tag', 'zocker' ),
            'add_new_item'               => esc_html__( 'Add New Tag', 'zocker' ),
            'new_item_name'              => esc_html__( 'New Tag Name', 'zocker' ),
            'separate_items_with_commas' => esc_html__( 'Separate Tags with commas', 'zocker' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove Tags', 'zocker' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used Tags', 'zocker' ),
            'not_found'                  => esc_html__( 'No Tags found.', 'zocker' ),
            'menu_name'                  => esc_html__( 'Tags', 'zocker' ),
        );

        $args = array(
            'hierarchical'          => false,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'show_in_rest'          => true,
            'rewrite'               => array( 'slug' => 'player-tag' ),
        );

        register_taxonomy( 'player_tag', 'zocker_player', $args );
    }
    
    // Team Post Type
    add_action( 'init','zocker_team', 0 );

    function zocker_team(){
        $labels = array(
            'name'               => esc_html__( 'Teams', 'post Category general name', 'zocker' ),
            'singular_name'      => esc_html__( 'Team', 'post Category singular name', 'zocker' ),
            'menu_name'          => esc_html__( 'Teams', 'admin menu', 'zocker' ),
            'name_admin_bar'     => esc_html__( 'Team', 'add new on admin bar', 'zocker' ),
            'add_new'            => esc_html__( 'Add New', 'Team', 'zocker' ),
            'add_new_item'       => esc_html__( 'Add New Team', 'zocker' ),
            'new_item'           => esc_html__( 'New Team', 'zocker' ),
            'edit_item'          => esc_html__( 'Edit Team', 'zocker' ),
            'view_item'          => esc_html__( 'View Team', 'zocker' ),
            'all_items'          => esc_html__( 'All Teams', 'zocker' ),
            'search_items'       => esc_html__( 'Search Teams', 'zocker' ),
            'parent_item_colon'  => esc_html__( 'Parent Teams:', 'zocker' ),
            'not_found'          => esc_html__( 'No Teams found.', 'zocker' ),
            'not_found_in_trash' => esc_html__( 'No Teams found in Trash.', 'zocker' ),
        );

        $args = array(
            'labels'             => $labels,
            'description'        => esc_html__( 'Description.', 'zocker' ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-index-card',
            'supports'           => array( 'title','thumbnail','editor','excerpt','elementor' ),
            'rewrite'            => array( 'slug' => 'all-teams' ),
        );

        register_post_type( 'zocker_team', $args );

        $labels = array(
            'name'                       => esc_html__( 'Categories', 'taxonomy general name', 'zocker' ),
            'singular_name'              => esc_html__( 'Category', 'taxonomy singular name', 'zocker' ),
            'search_items'               => esc_html__( 'Search Categorys', 'zocker' ),
            'popular_items'              => esc_html__( 'Popular Categorys', 'zocker' ),
            'all_items'                  => esc_html__( 'All Categorys', 'zocker' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Category', 'zocker' ),
            'update_item'                => esc_html__( 'Update Category', 'zocker' ),
            'add_new_item'               => esc_html__( 'Add New Category', 'zocker' ),
            'new_item_name'              => esc_html__( 'New Category Name', 'zocker' ),
            'separate_items_with_commas' => esc_html__( 'Separate Categorys with commas', 'zocker' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove Categorys', 'zocker' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used Categorys', 'zocker' ),
            'not_found'                  => esc_html__( 'No Categorys found.', 'zocker' ),
            'menu_name'                  => esc_html__( 'Categories', 'zocker' ),
        );

        $args = array(
            'hierarchical'          => true,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'show_in_rest'          => true,
            'rewrite'               => array( 'slug' => 'team-category' ),
        );

        register_taxonomy( 'team_category', 'zocker_team', $args );

        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                       => esc_html__( 'Tags', 'taxonomy general name', 'zocker' ),
            'singular_name'              => esc_html__( 'Tag', 'taxonomy singular name', 'zocker' ),
            'search_items'               => esc_html__( 'Search Tags', 'zocker' ),
            'popular_items'              => esc_html__( 'Popular Tags', 'zocker' ),
            'all_items'                  => esc_html__( 'All Tags', 'zocker' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Tag', 'zocker' ),
            'update_item'                => esc_html__( 'Update Tag', 'zocker' ),
            'add_new_item'               => esc_html__( 'Add New Tag', 'zocker' ),
            'new_item_name'              => esc_html__( 'New Tag Name', 'zocker' ),
            'separate_items_with_commas' => esc_html__( 'Separate Tags with commas', 'zocker' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove Tags', 'zocker' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used Tags', 'zocker' ),
            'not_found'                  => esc_html__( 'No Tags found.', 'zocker' ),
            'menu_name'                  => esc_html__( 'Tags', 'zocker' ),
        );

        $args = array(
            'hierarchical'          => false,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'show_in_rest'          => true,
            'rewrite'               => array( 'slug' => 'team-tag' ),
        );

        register_taxonomy( 'team_tag', 'zocker_team', $args );
    }

    if( ! function_exists( 'zocker_players_category' ) ){
        function zocker_players_category(){
            $cat_array = array();
            $cat_array[] = esc_html__( 'Select a category','zocker' );
            $terms = get_terms( array(
                'taxonomy'      => 'player_category',
                'hide_empty'    => true
            ) );
            if( is_array( $terms ) && $terms ){
                foreach( $terms as $term ){
                    $cat_array[$term->slug] = $term->name;
                }
            }
            return $cat_array;
        }
    }
    
    if( ! function_exists( 'zocker_teams_category' ) ){
        function zocker_teams_category(){
            $cat_array = array();
            $cat_array[] = esc_html__( 'Select a category','zocker' );
            $terms = get_terms( array(
                'taxonomy'      => 'team_category',
                'hide_empty'    => true
            ) );
            if( is_array( $terms ) && $terms ){
                foreach( $terms as $term ){
                    $cat_array[$term->slug] = $term->name;
                }
            }
            return $cat_array;
        }
    }

    /**
     * Single Template
     */
    add_filter( 'single_template', 'zocker_core_template_redirect' );

    if( ! function_exists( 'zocker_core_template_redirect' ) ){
        function zocker_core_template_redirect( $single_template ){

            global $post;

            // Player Single Page
            if( $post ){
                if( $post->post_type == 'zocker_player' ){
                    $single_template = ZOCKER_CORE_PLUGIN_TEMP . 'single-zocker_player.php';
                }
                if( $post->post_type == 'zocker_team' ){
                    $single_template = ZOCKER_CORE_PLUGIN_TEMP . 'single-zocker_team.php';
                }
            }

            return $single_template;
        }
    }

    /**
     * Archive Template
     */
    add_filter( 'archive_template', 'zocker_core_template_archive' );

    if( ! function_exists( 'zocker_core_template_archive' ) ){
        function zocker_core_template_archive( $archive_template ){

            global $post;

            // Player Archive Template
            if( $post ){
                if( $post->post_type == 'zocker_player' ){
                    $archive_template = ZOCKER_CORE_PLUGIN_TEMP . 'archive-zocker_player.php';
                }
                if( $post->post_type == 'zocker_team' ){
                    $archive_template = ZOCKER_CORE_PLUGIN_TEMP . 'archive-zocker_team.php';
                }
            }

            return $archive_template;
        }
    }
