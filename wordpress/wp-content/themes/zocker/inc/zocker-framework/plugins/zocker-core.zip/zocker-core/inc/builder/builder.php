<?php
    /**
     * Class For Builder
     */
    class ZockerBuilder{

        function __construct(){
            // register admin menus
        	add_action( 'admin_menu', [$this, 'register_settings_menus'] );

            // Custom Footer Builder With Post Type
			add_action( 'init',[ $this,'post_type' ],0 );

 		    add_action( 'elementor/frontend/after_enqueue_scripts', [ $this,'widget_scripts'] );

			add_filter( 'single_template', [ $this, 'load_canvas_template' ] );

            add_action( 'elementor/element/wp-page/document_settings/after_section_end', [ $this,'zocker_add_elementor_page_settings_controls' ],10,2 );

		}

		public function widget_scripts( ) {
			wp_enqueue_script( 'zocker-core',ZOCKER_PLUGDIRURI.'assets/js/zocker-core.js',array( 'jquery' ),'1.0',true );
		}


        public function zocker_add_elementor_page_settings_controls( \Elementor\Core\DocumentTypes\Page $page ){

			$page->start_controls_section(
                'zocker_header_option',
                [
                    'label'     => __( 'Header Option', 'zocker' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
			
			
            $page->add_control(
                'zocker_header_style',
                [
                    'label'     => __( 'Header Option', 'zocker' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'zocker' ),
    					'header_builder'       => __( 'Header Builder', 'zocker' ),
    				],
                    'default'   => 'prebuilt',
                ]
			);
			
            $page->add_control(
                'zocker_header_builder_option',
                [
                    'label'     => __( 'Header Name', 'zocker' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->zocker_header_choose_option(),
                    'condition' => [ 'zocker_header_style' => 'header_builder'],
                    'default'	=> ''
                ]
            );

            $page->end_controls_section();

            $page->start_controls_section(
                'zocker_footer_option',
                [
                    'label'     => __( 'Footer Option', 'zocker' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
            $page->add_control(
    			'zocker_footer_choice',
    			[
    				'label'         => __( 'Enable Footer?', 'zocker' ),
    				'type'          => \Elementor\Controls_Manager::SWITCHER,
    				'label_on'      => __( 'Yes', 'zocker' ),
    				'label_off'     => __( 'No', 'zocker' ),
    				'return_value'  => 'yes',
    				'default'       => 'yes',
    			]
    		);
            $page->add_control(
                'zocker_footer_style',
                [
                    'label'     => __( 'Footer Style', 'zocker' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'zocker' ),
    					'footer_builder'       => __( 'Footer Builder', 'zocker' ),
    				],
                    'default'   => 'prebuilt',
                    'condition' => [ 'zocker_footer_choice' => 'yes' ],
                ]
            );
            $page->add_control(
                'zocker_footer_builder_option',
                [
                    'label'     => __( 'Footer Name', 'zocker' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->zocker_footer_choose_option(),
                    'condition' => [ 'zocker_footer_style' => 'footer_builder','zocker_footer_choice' => 'yes' ],
                    'default'	=> ''
                ]
            );

			$page->end_controls_section();

        }

		public function register_settings_menus(){
			add_menu_page(
				esc_html__( 'Zocker Builder', 'zocker' ),
            	esc_html__( 'Zocker Builder', 'zocker' ),
				'manage_options',
				'zocker',
				[$this,'register_settings_contents__settings'],
				'dashicons-admin-site',
				2
			);

			add_submenu_page('zocker', esc_html__('Footer Builder', 'zocker'), esc_html__('Footer Builder', 'zocker'), 'manage_options', 'edit.php?post_type=zocker_footer');
			add_submenu_page('zocker', esc_html__('Header Builder', 'zocker'), esc_html__('Header Builder', 'zocker'), 'manage_options', 'edit.php?post_type=zocker_header');
		}

		// Callback Function
		public function register_settings_contents__settings(){
            echo '<h2>';
			    echo esc_html__( 'Welcome To Header And Footer Builder Of This Theme','zocker' );
            echo '</h2>';
		}

		public function post_type() {

			$labels = array(
				'name'               => __( 'Footer', 'zocker' ),
				'singular_name'      => __( 'Footer', 'zocker' ),
				'menu_name'          => __( 'Zocker Footer Builder', 'zocker' ),
				'name_admin_bar'     => __( 'Footer', 'zocker' ),
				'add_new'            => __( 'Add New', 'zocker' ),
				'add_new_item'       => __( 'Add New Footer', 'zocker' ),
				'new_item'           => __( 'New Footer', 'zocker' ),
				'edit_item'          => __( 'Edit Footer', 'zocker' ),
				'view_item'          => __( 'View Footer', 'zocker' ),
				'all_items'          => __( 'All Footer', 'zocker' ),
				'search_items'       => __( 'Search Footer', 'zocker' ),
				'parent_item_colon'  => __( 'Parent Footer:', 'zocker' ),
				'not_found'          => __( 'No Footer found.', 'zocker' ),
				'not_found_in_trash' => __( 'No Footer found in Trash.', 'zocker' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'zocker_footer', $args );

			$labels = array(
				'name'               => __( 'Header', 'zocker' ),
				'singular_name'      => __( 'Header', 'zocker' ),
				'menu_name'          => __( 'Zocker Header Builder', 'zocker' ),
				'name_admin_bar'     => __( 'Header', 'zocker' ),
				'add_new'            => __( 'Add New', 'zocker' ),
				'add_new_item'       => __( 'Add New Header', 'zocker' ),
				'new_item'           => __( 'New Header', 'zocker' ),
				'edit_item'          => __( 'Edit Header', 'zocker' ),
				'view_item'          => __( 'View Header', 'zocker' ),
				'all_items'          => __( 'All Header', 'zocker' ),
				'search_items'       => __( 'Search Header', 'zocker' ),
				'parent_item_colon'  => __( 'Parent Header:', 'zocker' ),
				'not_found'          => __( 'No Header found.', 'zocker' ),
				'not_found_in_trash' => __( 'No Header found in Trash.', 'zocker' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'zocker_header', $args );
		}

		function load_canvas_template( $single_template ) {

			global $post;

			if ( 'zocker_footer' == $post->post_type || 'zocker_header' == $post->post_type ) {

				$elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

				if ( file_exists( $elementor_2_0_canvas ) ) {
					return $elementor_2_0_canvas;
				} else {
					return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
				}
			}

			return $single_template;
		}

        public function zocker_footer_choose_option(){

			$zocker_post_query = new WP_Query( array(
				'post_type'			=> 'zocker_footer',
				'posts_per_page'	    => -1,
			) );

			$zocker_builder_post_title = array();
			$zocker_builder_post_title[''] = __('Select a Footer','Zocker');

			while( $zocker_post_query->have_posts() ) {
				$zocker_post_query->the_post();
				$zocker_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $zocker_builder_post_title;

		}
		
		public function zocker_header_choose_option(){

			$zocker_post_query = new WP_Query( array(
				'post_type'			=> 'zocker_header',
				'posts_per_page'	    => -1,
			) );

			$zocker_builder_post_title = array();
			$zocker_builder_post_title[''] = __('Select a Header','Zocker');

			while( $zocker_post_query->have_posts() ) {
				$zocker_post_query->the_post();
				$zocker_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $zocker_builder_post_title;

        }

    }

    $builder_execute = new ZockerBuilder();