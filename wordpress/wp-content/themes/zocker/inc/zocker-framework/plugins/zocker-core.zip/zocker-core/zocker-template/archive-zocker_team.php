<?php 

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    // header
    get_header();
	
    echo '<section class="vs-team-wrapper vs-team-layout1 space-top newsletter-pb">';
        echo '<div class="container">';
            echo '<div class="row justify-content-center">';
				if( have_posts() ):
					while( have_posts() ):
						the_post();
						echo '<div class="col-xl-3 col-lg-4 col-sm-6">';
                            echo '<div class="vs-team bg-fluid">';
                                if( has_post_thumbnail( ) ){
                                    echo '<div class="team-img mb-35">';
                                        echo '<a href="'.esc_url( get_permalink() ).'">';
                                            the_post_thumbnail();
                                        echo '</a>';
                                    echo '</div>';
                                }
                                if( get_the_title() ){
                                    echo '<h3 class="team-name h5 text-white mb-0"><a href="'.esc_url( get_permalink() ).'">'.esc_html( get_the_title() ).'</a></h3>';
                                }
                                if( ! empty( zocker_meta( 'zocker_team_player' ) ) ){
                                    echo '<span class="team-team-degi text-light-white fs-xs">'.esc_html( zocker_meta( 'zocker_team_player' ) ).'</span>';
                                }
                            echo '</div>';
						echo '</div>';
					endwhile;
					wp_reset_postdata();
				endif;
			echo '</div>';
		echo '</div>';
	echo '</section>';
	
	get_footer();