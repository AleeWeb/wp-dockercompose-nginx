<?php 

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    // header
    get_header();
	
	echo '<section class="vs-team-wrapper space-top newsletter-pb">';
	  	echo '<div class="container">';
	    	echo '<div class="row">';
                if ( is_active_sidebar( 'zocker-team-sidebar' ) ) {
                    $zocker_team_class = "col-lg-8";
                }else{
                    $zocker_team_class = "col-lg-12";
                }
    	    	echo '<div class="'.esc_attr( $zocker_team_class ).'">';
    				while( have_posts( ) ) :
    	                the_post();
    	                the_content();

    	            endwhile;
    	            wp_reset_postdata();
    			echo '</div>';
                if ( is_active_sidebar( 'zocker-team-sidebar' ) ) {
                    get_sidebar( 'team' );
                }
			echo '</div>';
		echo '</div>';
	echo '</section>';
	
	get_footer();