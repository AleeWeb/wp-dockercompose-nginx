=== WP Owl Carousel ===
Contributors: Dabuuker
Tags: carousel, owl carousel, slideshow, slider
Requires at least: 4.0
Tested up to: 4.3
Stable tag: 1.1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Owl Carousel integration for Wordpress

== Description ==
Owl Carousel integration for Wordpress

Owl Carousel author: Bartosz Wojciechowski
http://owlgraphic.com/owlcarousel/

For now, works only with images.

== Screenshots ==
1. Click Add or Upload files to insert images
2. When images selected, click use this file
3. Copy the shortcode and paste it anywhere
4. View post/page to see results

== Installation ==
Go to your Wordpress Dashboard. From there select Plugins -> Add New. Search for \'WP Owl Carousel\', make sure it found the right plugin and click Install Now.

Alternatively, extract the zip file and upload the contents to the wp-content/plugins/ directory of your WordPress installation and then activate the plugin from the plugins page.

== Changelog ==
= 1.1.0 =
* Added ability to link to a different image size and specify a rel attribute for lightboxes
= 1.0.0 =
* First release